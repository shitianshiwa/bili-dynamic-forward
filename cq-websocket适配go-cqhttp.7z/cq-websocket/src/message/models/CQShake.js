const CQTag = require('../CQTag')

module.exports = class CQShake extends CQTag {
  constructor () {
    super('shake')
  }
}
